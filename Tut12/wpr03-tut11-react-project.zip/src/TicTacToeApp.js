import Board from "./Board";

export default function TicTacToeApp() {
    return (
        <Board />
    );
}