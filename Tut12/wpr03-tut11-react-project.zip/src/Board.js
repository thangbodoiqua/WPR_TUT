import Square from "./Square";

export default function Board() {
    const squares = new Array(9).fill(null);
    return (
        <div style={{
            width: 300,
            height: 300,
            display: 'flex',
            flexWrap: 'wrap',
            border: '2px solid #333'
        }}>{squares.map(item => <Square value={item} />)}</div>
    );
}