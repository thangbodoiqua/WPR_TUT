import Flashcard from "./Flashcard";

export default function FlashcardContainer({ word, def }) {
    return (
        <div id="flashcard-container">
            <div className="flashcard-box">
                <Flashcard type="word" text={word} />
                <Flashcard type="definition" text={def} />
            </div>
        </div>
    );
}