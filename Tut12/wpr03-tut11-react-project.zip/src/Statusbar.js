export default function Statusbar({ func, index, count }) {
    return (
        <div id="status-bar">
            <button disabled={index === 1} id="prev">&larr;</button>
            <strong>{index}</strong> / <span>{count}</span>
            <button disabled={index === count} id="next" onClick={func}>&rarr;</button>
        </div>
    );
}