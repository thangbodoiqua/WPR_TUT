import FlashcardContainer from "./FlashcardContainer";
import Statusbar from "./Statusbar";
import './FlashcardApp.css';
import React from "react";

const dict = {
  "pretty": "xinh đẹp",
  "car": "xe hơi",
  "study": "học tập",
  "life": "cuộc sống",
  "enormous": "to lớn",
  "computer": "máy tính"
};

const words = Object.keys(dict);
const meanings = Object.values(dict);

export default class FlashcardApp extends React.Component {
  constructor() {
    super();
    this.state = {
      index: 0
    };
  }
  render() {
    const i = this.state.index;
    const word = words[i];
    const def = meanings[i];
    const count = words.length;
    const next = () => {
      this.setState({
        index: i + 1
      });
    }
    return (
      <div id="main">
        <FlashcardContainer word={word} def={def} />
        <Statusbar func={next} index={i + 1} count={count} />
      </div>
    );
  }
}
