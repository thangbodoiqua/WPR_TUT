export default function Square({ value }) {
    return (
        <div style={{
            width: 100,
            height: 100,
            boxSizing: 'border-box',
            border: '2px solid #333',
            fontSize: 45,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center'
        }}>{value}</div>
    );
}